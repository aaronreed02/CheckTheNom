﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreNom.Models.Meals
{
    public class Ingredient
    {
        public string Name { get; set; }
        public Nullable<double> Amount { get; set; }
        public string Measurement { get; set; } 
        public bool Optional { get; set; }

        public Ingredient(string name, double amount, string measurement, bool optional )
        {
            Name = name;
            Amount = amount;
            Measurement = measurement;
            Optional = optional;
        }
    }
}
