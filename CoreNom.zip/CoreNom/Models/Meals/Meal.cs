﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreNom.Models.Meals
{
    public class Meal
    {
        public string Recipe { get; set; }
        public object[] Ingredients { get; set; }
        public int Calories { get; set; }
        public int Servings { get;set; }
        public bool VegSuitable { get; set; }
        public bool FreezeSuitable { get; set; }
        public bool GlutenSuitable { get; set; }
        public string Category { get; set; }
        public int Id { get; set; }

        public Meal(string recipe, object[] ingredients, int calories, int servings, bool vegSuitable, bool freezeSuitable, bool glutenSuitable, string category, int id)
        {
            Recipe = recipe;
            Ingredients = ingredients;
            Calories = calories;
            Servings = servings;
            VegSuitable = vegSuitable;
            FreezeSuitable = freezeSuitable;
            GlutenSuitable = glutenSuitable;
            Category = category;
            Id = id;

        }
    }
}
