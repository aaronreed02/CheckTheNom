﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreNom.Models.Meals.Recipes;

namespace CoreNom.Models.Meals.Recipes
{
    public class Recipes
    {
        public object[] MealList()
        {
            List<Meal> Meals = new List<Meal>();

            RecipeIngredients a = new RecipeIngredients();

            #region Breakfasts
            string Breakfast = "Breakfast";
            Meal AppleAndCinnamonPancakes = new Meal("Apple and Cinnamon Pancakes", a.AppleAndCinnamonPancakes(), 341, 1, true, false, true, Breakfast, 0);
            Meal FullEnglishWraps = new Meal("Full English Wraps", a.FullEnglishWraps(), 220, 1, false, false, false, Breakfast, 1);
            Meal BaconPotatoAndSpringOnionFrittata = new Meal("Bacon, Potato and Spring Onion Frittata", a.BaconPotatoAndSpringOnionFrittata(), 249, 4, false, true, true, Breakfast, 2);
            Meal CreamyMushroomBruschetta = new Meal("Creamy Mushroom Bruschetta", a.CreamyMushroomBruschetta(), 164, 2, true, false, true, Breakfast, 3);
            Meal BreakfastMuffins = new Meal("Breakfast Muffins", a.BreakfastMuffins(), 66, 12, true, true, true, Breakfast, 4);
            Meal MapleAndBaconFrenchToastWithFruit = new Meal("Maple and Bacon French Toast with Fruit", a.MapleAndBaconFrenchToastWithFruit(), 518, 1, false, false, false, Breakfast, 5);
            Meal HashBrowns = new Meal("Hash Browns", a.HashBrowns(), 77, 8, true, true, true, Breakfast, 6);
            Meal WrapsDeHuevo = new Meal("Wraps de Huevo", a.WrapsDeHuevo(), 234, 1, true, false, false, Breakfast, 7);
            Meal LemonAndBlueberryBakedOats = new Meal("Lemon and Blueberry Baked Oats", a.LemonAndBlueberryBakedOats(), 440, 1, true, true, true, Breakfast, 8);
            Meal CarrotCakeOvernightOats = new Meal("Carrot Cake Overnight Oats", a.CarrotCakeOvernightOats(), 318, 1, true, false, false, Breakfast, 9);
            #endregion

            #region Fakeaways
            string Fakeaway = "Fakeaway";
            Meal TandooriChickenKebab = new Meal("Tandoori Chicken Kebab", a.TandooriChickenKebab(), 236, 4, false, true, true, Fakeaway, 10);
            Meal ChickenBalti = new Meal("Chicken Balti", a.ChickenBalti(), 373, 4, false, true, true, Fakeaway, 11);
            Meal ChickenAndMushroomStirFry = new Meal("Chicken and Mushroom Stir Fry", a.ChickenAndMushroomStirFry(), 274, 2, false, true, false, Fakeaway, 12);
            Meal ChickenSatay = new Meal("Chicken Satay", a.ChickenSatay(), 293, 6, false, true, true, Fakeaway, 13);
            #endregion

            //Breakfast
            Meals.Add(AppleAndCinnamonPancakes);
            Meals.Add(FullEnglishWraps);
            Meals.Add(BaconPotatoAndSpringOnionFrittata);
            Meals.Add(CreamyMushroomBruschetta);
            Meals.Add(BreakfastMuffins);
            Meals.Add(MapleAndBaconFrenchToastWithFruit);
            Meals.Add(HashBrowns);
            Meals.Add(WrapsDeHuevo);
            Meals.Add(LemonAndBlueberryBakedOats);
            Meals.Add(CarrotCakeOvernightOats);
            //Fakeaway
            Meals.Add(TandooriChickenKebab);
            Meals.Add(ChickenBalti);
            Meals.Add(ChickenAndMushroomStirFry);
            Meals.Add(ChickenSatay);

            return Meals.ToArray();
        }
    }
}
