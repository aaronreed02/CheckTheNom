﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreNom.Models.Meals.Recipes
{
    public class RecipeIngredients
    {
        #region Breakfasts
        public object[] AppleAndCinnamonPancakes()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Oats", 40, "g", false);
            Ingredient b = new Ingredient("Apple", 1.5, "", false);
            Ingredient c = new Ingredient("Skimmed Milk", 50, "ml", false);
            Ingredient d = new Ingredient("Ground Cinnamon", 0.25, "tsp", false);
            Ingredient e = new Ingredient("Granulated Sweetener", 1, "tsp", false);
            Ingredient f = new Ingredient("Egg", 2, "", false);
            Ingredient g = new Ingredient("Fat-Free Natural Yoghurt", 2, "tbsp", false);
            Ingredient h = new Ingredient("Fresh Berries", 1, "", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);
            ingredients.Add(h);

            return ingredients.ToArray();
        }

        public object[] FullEnglishWraps()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Egg", 1, "", false);
            Ingredient b = new Ingredient("Mushroom", 2, "", false);
            Ingredient c = new Ingredient("Bacon Medallion", 1, "", false);
            Ingredient d = new Ingredient("Cherry Tomato", 4, "", true);
            Ingredient e = new Ingredient("Baked Beans", 3, "tbsp", true);
            Ingredient f = new Ingredient("Low-Fat Sausage", 1, "", false);
            Ingredient g = new Ingredient("Reduced-Fat Cheddar", 10, "g", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);

            return ingredients.ToArray();
        }

        public object[] BaconPotatoAndSpringOnionFrittata()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Potato", 200, "g", false);
            Ingredient b = new Ingredient("Onion", 1, "", false);
            Ingredient c = new Ingredient("Bacon Medallion", 6, "", false);
            Ingredient d = new Ingredient("Spring Onion", 6, "", false);
            Ingredient e = new Ingredient("Egg", 8, "", false);
            Ingredient f = new Ingredient("Fresh Parsley", 4, "g", false);
            Ingredient g = new Ingredient("Reduced-Fat Cheddar", 4, "g", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);

            return ingredients.ToArray();
        }

        public object[] CreamyMushroomBruschetta()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Chestnut Mushroom", 250, "g", false);
            Ingredient b = new Ingredient("Garlic Clove", 2, "", false);
            Ingredient c = new Ingredient("Gluten-Free Cibatta", 2, "", false);
            Ingredient d = new Ingredient("Low-Fat Cream Cheese", 25, "g", false);
            Ingredient e = new Ingredient("Fresh Basil", 1, "tbsp", false);
            Ingredient f = new Ingredient("Fresh Chives", 1, "tbsp", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);

            return ingredients.ToArray();
        }

        public object[] BreakfastMuffins()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Egg", 12, "", false);
            Ingredient b = new Ingredient("Button Mushroom", 6, "", false);
            Ingredient c = new Ingredient("Garlic Clove", 2, "", false);
            Ingredient d = new Ingredient("Fresh Parsley", 1, "", false);
            Ingredient e = new Ingredient("Spinach", 100, "g", false);
            Ingredient f = new Ingredient("Red Pepper", 0.5, "", false);
            Ingredient g = new Ingredient("Smoked Sweet Paprika", 1, "tsp", false);
            Ingredient h = new Ingredient("Broccoli", 200, "g", false);
            Ingredient i = new Ingredient("Red Onion", 0.5, "", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);
            ingredients.Add(h);
            ingredients.Add(i);

            return ingredients.ToArray();
        }

        public object[] MapleAndBaconFrenchToastWithFruit()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Bacon Medallion", 4, "", false);
            Ingredient b = new Ingredient("Egg", 2, "", false);
            Ingredient c = new Ingredient("Granulated Sweetener", 1, "tsp", false);
            Ingredient d = new Ingredient("Wholemeal Bread", 1, "", false);
            Ingredient e = new Ingredient("Maple Syrup", 1, "tbsp", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);

            return ingredients.ToArray();
        }

        public object[] HashBrowns()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Baking Potato", 4, "", false);
            Ingredient b = new Ingredient("Onion Granules", 1, "tsp", false);
            Ingredient c = new Ingredient("Egg", 1, "", false);
            Ingredient d = new Ingredient("Xanthan Gum", 2, "tsp", false);
            Ingredient e = new Ingredient("Salt", 0.5, "tsp", false);
            Ingredient f = new Ingredient("Fried Egg", 5, "", true);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);

            return ingredients.ToArray();
        }

        public object[] WrapsDeHuevo()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Egg", 1, "", false);
            Ingredient b = new Ingredient("Hot Sauce", 1, "", false);
            Ingredient c = new Ingredient("Red Onion", 0.5, "", false);
            Ingredient d = new Ingredient("Red Pepper", 0.5, "", false);
            Ingredient e = new Ingredient("Garlic Granules", 1, "", false);
            Ingredient f = new Ingredient("Tinned Mixed Beans", 200, "g", false);
            Ingredient g = new Ingredient("Reduced-Fat Cheddar", 20, "g", false);
            Ingredient h = new Ingredient("Fresh Coriander", 10, "g", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);
            ingredients.Add(h);

            return ingredients.ToArray();
        }

        public object[] LemonAndBlueberryBakedOats()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Oats", 40, "g", false);
            Ingredient b = new Ingredient("Fat-Free Natural Yoghurt", 175, "g", false);
            Ingredient c = new Ingredient("Vanilla Extract", 1, "tsp", false);
            Ingredient d = new Ingredient("Granulated Sweetener", 0.75, "tbsp", false);
            Ingredient e = new Ingredient("Lemon", 0.5, "", false);
            Ingredient f = new Ingredient("Egg", 2, "", false);
            Ingredient g = new Ingredient("Blueberries", 50, "g", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);

            return ingredients.ToArray();

        }

        public object[] CarrotCakeOvernightOats()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Oats", 40, "g", false);
            Ingredient b = new Ingredient("Weetabix", 2, "", true);
            Ingredient c = new Ingredient("Vanilla-Flavoured Fat-Free Yoghurt", 175, "g", false);
            Ingredient d = new Ingredient("Fat-Free Natural Yoghurt", 175, "g", true);
            Ingredient e = new Ingredient("Vanilla Extract", 0.5, "tsp", true);
            Ingredient f = new Ingredient("Granulated Sweetener", 1, "tsp", true);
            Ingredient g = new Ingredient("Carrot", 1, "", false);
            Ingredient h = new Ingredient("Mixed Spice", 0.25, "tsp", false);
            Ingredient i = new Ingredient("Ground Ginger", 5, "g", false);
            Ingredient j = new Ingredient("Ground Cinnamon", 5, "g", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);
            ingredients.Add(h);
            ingredients.Add(i);
            ingredients.Add(j);

            return ingredients.ToArray();
        }
        #endregion

        #region Fakeaways
        public object[] TandooriChickenKebab()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Fat-Free Greek-Style Yoghurt", 250, "g", false);
            Ingredient b = new Ingredient("Tandoori Spice Mix", 4, "tbsp", false);
            Ingredient c = new Ingredient("Garlic Clove", 1, "", false);
            Ingredient d = new Ingredient("Root Ginger", 1, "tbsp", false);
            Ingredient e = new Ingredient("Lemon", 0.5, "", false);
            Ingredient f = new Ingredient("Dark Soy Sauce", 1, "tsp", false);
            Ingredient g = new Ingredient("Salt", 0.5, "tsp", false);
            Ingredient h = new Ingredient("Red Food Colouring", 1, "", true);
            Ingredient i = new Ingredient("Chicken Thigh", 600, "g", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);
            ingredients.Add(h);
            ingredients.Add(i);

            return ingredients.ToArray();
        }

        public object[] ChickenBalti()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Chicken Breast", 4, "", false);
            Ingredient b = new Ingredient("Cinnamon Stick", 1, "", false);
            Ingredient c = new Ingredient("Ground Cinnamon", 1, "tsp", true);
            Ingredient d = new Ingredient("Dried Chilli Flakes", 0.5, "tsp", false);
            Ingredient e = new Ingredient("Chicken Stock Cube", 1.5, "", false);
            Ingredient f = new Ingredient("Tin Chopped Tomatoes", 400, "g", false);
            Ingredient g = new Ingredient("Red Pepper", 1, "", false);
            Ingredient h = new Ingredient("Yellow Pepper", 1, "", false);
            Ingredient i = new Ingredient("Orange Pepper", 1, "", false);
            Ingredient j = new Ingredient("Garam Masala", 1, "tsp", false);
            Ingredient k = new Ingredient("Onion", 2, "", false);
            Ingredient l = new Ingredient("Root Ginger", 6, "g", false);
            Ingredient m = new Ingredient("Garlic Clove", 2, "", false);
            Ingredient n = new Ingredient("Ground Tumeric", 1, "tsp", false);
            Ingredient o = new Ingredient("Dried Chili Flakes", 0.5, "tsp", false);
            Ingredient p = new Ingredient("Smoked Sweet Paprika", 2, "tbsp", false);
            Ingredient q = new Ingredient("Ground Cumin", 2, "tsp", false);
            Ingredient r = new Ingredient("Ground Coriander", 2, "tsp", false);
            Ingredient s = new Ingredient("Ground Cinnamon", 1, "tsp", false);
            Ingredient t = new Ingredient("Salt", 1, "tsp", false);
            Ingredient u = new Ingredient("Tomato Puree", 3, "tbsp", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);
            ingredients.Add(h);
            ingredients.Add(i);
            ingredients.Add(j);
            ingredients.Add(k);
            ingredients.Add(l);
            ingredients.Add(m);
            ingredients.Add(n);
            ingredients.Add(o);
            ingredients.Add(p);
            ingredients.Add(q);
            ingredients.Add(r);
            ingredients.Add(s);
            ingredients.Add(t);
            ingredients.Add(u);

            return ingredients.ToArray();
        }

        public object[] ChickenAndMushroomStirFry()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Onion", 1, "", false);
            Ingredient b = new Ingredient("Chicken Breast", 2, "", false);
            Ingredient c = new Ingredient("Red Pepper", 1, "", false);
            Ingredient d = new Ingredient("Green Pepper", 1, "", false);
            Ingredient e = new Ingredient("Broccoli Florets", 200, "g", false);
            Ingredient f = new Ingredient("Garlic Clove", 1, "", false);
            Ingredient g = new Ingredient("Root Ginger", 0.5, "tsp", false);
            Ingredient h = new Ingredient("Spring Onion", 6, "", false);
            Ingredient i = new Ingredient("Baby Corn", 200, "g", false);
            Ingredient j = new Ingredient("Button Mushroom", 200, "g", false);
            Ingredient k = new Ingredient("Soy Sauce", 4, "tbsp", false);
            Ingredient l = new Ingredient("Oyster Sauce", 2, "tbsp", false);
            Ingredient m = new Ingredient("Rice Vinegar", 2, "tbsp", false);
            Ingredient n = new Ingredient("White Wine Vinegar", 2, "tbsp", true);
            Ingredient o = new Ingredient("Beef Stock Cube", 1, "", false);
            Ingredient p = new Ingredient("Rice", 150, "g", true);
            Ingredient q = new Ingredient("Noodles", 150, "g", true);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);
            ingredients.Add(h);
            ingredients.Add(i);
            ingredients.Add(j);
            ingredients.Add(k);
            ingredients.Add(l);
            ingredients.Add(m);
            ingredients.Add(n);
            ingredients.Add(o);
            ingredients.Add(p);
            ingredients.Add(q);

            return ingredients.ToArray();
        }

        public object[] ChickenSatay()
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Ingredient a = new Ingredient("Onion", 1, "", false);
            Ingredient b = new Ingredient("Chicken Breast", 4, "", false);
            Ingredient c = new Ingredient("Carrot", 2, "", false);
            Ingredient d = new Ingredient("Broccoli Florets", 200, "g", false);
            Ingredient e = new Ingredient("Mangetout", 100, "g", false);
            Ingredient f = new Ingredient("Red Pepper", 1, "", false);
            Ingredient g = new Ingredient("Yellow Pepper", 1, "", false);
            Ingredient h = new Ingredient("Spring Onion", 4, "", false);
            Ingredient i = new Ingredient("Light Soy Sauce", 4, "tbsp", false);
            Ingredient j = new Ingredient("Garlic Clove", 3, "", false);
            Ingredient k = new Ingredient("Root Ginger", 12, "g", false);
            Ingredient l = new Ingredient("Red Chilli", 1, "", false);
            Ingredient m = new Ingredient("Ground Cumin", 0.25, "tsp", false);
            Ingredient n = new Ingredient("Ground Coriander", 0.5, "tsp", false);
            Ingredient o = new Ingredient("Ground Tumeric", 1, "tbsp", false);
            Ingredient p = new Ingredient("Fish Sauce", 1, "tbsp", false);
            Ingredient q = new Ingredient("Worcestershire Sauce", 1, "tbsp", true);
            Ingredient r = new Ingredient("Granulated Sweetener", 3, "tbsp", false);
            Ingredient s = new Ingredient("Alpro Coconut Drink", 600, "ml", false);
            Ingredient t = new Ingredient("Reduced-Fat Peanut Butter Powder", 4, "tbsp", false);
            Ingredient u = new Ingredient("Cornflour", 2, "tbsp", false);

            ingredients.Add(a);
            ingredients.Add(b);
            ingredients.Add(c);
            ingredients.Add(d);
            ingredients.Add(e);
            ingredients.Add(f);
            ingredients.Add(g);
            ingredients.Add(h);
            ingredients.Add(i);
            ingredients.Add(j);
            ingredients.Add(k);
            ingredients.Add(l);
            ingredients.Add(m);
            ingredients.Add(n);
            ingredients.Add(o);
            ingredients.Add(p);
            ingredients.Add(q);
            ingredients.Add(r);
            ingredients.Add(s);
            ingredients.Add(t);
            ingredients.Add(u);

            return ingredients.ToArray();
        }
        #endregion
    }
}
