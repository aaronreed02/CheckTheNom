﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreNom.Models.Meals;
using CoreNom.Models.Meals.Recipes;
using Microsoft.AspNetCore.Mvc;

namespace CoreNom.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Meals()
        {
            Recipes Meals = new Recipes();
            ViewBag.List = Meals.MealList();

            return View();
        }

        public IActionResult CreateMealPage(string Recipe, int Calories, int Servings, bool Veg, bool Freeze, bool Gluten, string Category)
        {
            Recipes pls = new Recipes();

            List<object> Ingredients = new List<object>();
            foreach (Meal item in pls.MealList())
            {
                if (item.Recipe == Recipe)
                {
                    Ingredients = item.Ingredients.ToList();
                }
                else
                    continue;
            }

            ViewBag.Recipe = Recipe;
            ViewBag.Ingredients = Ingredients.ToArray();
            ViewBag.Calories = Calories;
            ViewBag.Servings = Servings;
            ViewBag.Veg = Veg;
            ViewBag.Freeze = Freeze;
            ViewBag.Gluten = Gluten;
            ViewBag.Category = Category;

            return View("Meal");
        }

        public IActionResult Check()
        {
            Recipes Meals = new Recipes();
            ViewBag.List = Meals.MealList();

            return View();
        }

        public IActionResult Books()
        {
            return View();
        }
    }
}