﻿function MealsTravel() {
    window.location.href = "Home/Meals";
}

function CheckTravel() {
    window.location.href = "Home/Check";
}

function BooksTravel() {
    window.location.href = "Home/Books";
}

function HomeStyle() {
    window.location.href = "https://www.amazon.com/dp/1250269555?tag=macmillan-20";
}

function EverydayLight() {
    window.location.href = "https://www.amazon.co.uk/Pinch-Nom-Everyday-slimming-calories/dp/1529026407/ref=as_li_ss_tl?ie=UTF8&linkCode=sl1&tag=pincofnom-21&linkId=13d73686e3493303d0847cb11fe03042&language=en_GB";
}

function FoodPlanner() {
    window.location.href = "https://www.amazon.co.uk/gp/product/152902644X/ref=as_li_tl?ie=UTF8&camp=1634&creative=6738&creativeASIN=152902644X&linkCode=as2&tag=pincofnom-21&linkId=8be807046e0f03d8d6bc2b4cee8442b2";
}