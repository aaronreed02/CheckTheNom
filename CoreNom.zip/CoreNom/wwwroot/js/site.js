﻿function MealsTravel() {
    window.location.href = "Home/Meals";
}

function CheckTravel() {
    window.location.href = "Home/Check";
}

function BooksTravel() {
    window.location.href = "Home/Books";
}